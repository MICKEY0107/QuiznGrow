const express = require('express');
const Test = require('../models/Test');  // Assuming you have a Test model in models/Test.js
const router = express.Router();

// Example route to generate a test based on difficulty
router.get('/generate-test', async (req, res) => {
  const { subject, difficulty } = req.query;
  
  try {
    const questions = await Test.find({ subject, difficulty }).limit(10);  // Get 10 questions for the test
    if (questions.length === 0) {
      return res.status(404).json({ message: 'No questions found' });
    }
    res.json(questions);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching test questions' });
  }
});

module.exports = router;
