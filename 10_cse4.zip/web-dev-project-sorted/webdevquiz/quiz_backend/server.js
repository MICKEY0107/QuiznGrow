const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();
const port = 5000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/quizapp', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch(err => {
    console.error("Error connecting to MongoDB:", err);
  });

// Define the schema and model for quiz questions
const quizSchema = new mongoose.Schema({
  subject: String,
  difficulty: String,
  questions: [
    {
      question: String,
      options: [String],
      correct_answer: String
    }
  ]
});

const Quiz = mongoose.model('Quiz', quizSchema);

// Middleware
app.use(cors());
app.use(express.json());

// API route to fetch quiz questions
app.get('/api/questions', async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json(quizzes);  // Send the quiz questions to the frontend
  } catch (error) {
    console.error("Error fetching quiz questions:", error);
    res.status(500).json({ message: "Error fetching quiz questions" });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
