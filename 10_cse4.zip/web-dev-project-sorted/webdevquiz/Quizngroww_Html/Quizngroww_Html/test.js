let currentQuestionIndex = 0;
let selectedOptions = {};
let questions = [];
let timerInterval;

// Fetch questions from the backend (API)
async function fetchQuestions() {
  try {
    const response = await fetch('http://localhost:5000/api/questions');
    if (!response.ok) {
      throw new Error('Failed to fetch questions');
    }
    const quizzes = await response.json();
    questions = quizzes[0].questions; // Assuming you want the first quiz
    loadQuestion();
  } catch (error) {
    console.error('Error fetching questions:', error);
    alert('Failed to load quiz questions.');
  }
}

// Function to load a specific question
function loadQuestion() {
  const question = questions[currentQuestionIndex];
  if (question) {
    document.getElementById('question-text').textContent = question.question;

    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';  // Clear previous options

    question.options.forEach(option => {
      const button = document.createElement('button');
      button.classList.add('option');
      button.textContent = option;
      button.onclick = () => selectOption(option);
      optionsContainer.appendChild(button);
    });
  }
}

// Store the selected option for the current question
function selectOption(option) {
  selectedOptions[currentQuestionIndex] = option;
}

// Navigate to the next question
function nextQuestion() {
  if (currentQuestionIndex < questions.length - 1) {
    currentQuestionIndex++;
    loadQuestion();
  }
}

// Navigate to the previous question
function prevQuestion() {
  if (currentQuestionIndex > 0) {
    currentQuestionIndex--;
    loadQuestion();
  }
}

// Submit the quiz and calculate score
function submitQuiz() {
  let score = 0;
  questions.forEach((question, index) => {
    if (selectedOptions[index] === question.correct_answer) {
      score++;
    }
  });

  alert(`You scored ${score} out of ${questions.length}`);
  // Disable the submit button after submission
  document.getElementById('submit-btn').disabled = true;
  stopTimer();
}

// Timer functionality
let timeLeft = 60; // Set time limit (e.g., 1 minute)
const timerElement = document.getElementById('timer');

function startTimer() {
  timerInterval = setInterval(() => {
    if (timeLeft > 0) {
      timeLeft--;
      timerElement.textContent = `Time left: ${timeLeft} seconds`;
    } else {
      clearInterval(timerInterval);
      alert("Time's up!");
      submitQuiz();
    }
  }, 1000);
}

// Stop timer when quiz is submitted
function stopTimer() {
  clearInterval(timerInterval);
}

startTimer(); // Start the timer as soon as the page loads

fetchQuestions();  // Fetch the quiz questions from the backend
