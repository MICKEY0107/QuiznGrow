// Function to confirm logout and trigger the backend logout
function confirmLogout() {
    const confirmMessage = "Are you sure you want to log out?";
    const userConfirmed = confirm(confirmMessage); // Show confirmation dialog
  
    if (userConfirmed) {
      logoutUser(); // If confirmed, log out the user
    }
  }
  
  // Function to handle the backend logout
  async function logoutUser() {
    try {
      const response = await fetch('http://localhost:5000/api/logout', {
        method: 'POST', // Assume logout is handled via POST request
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'same-origin', // Include cookies for session handling if required
      });
  
      if (response.ok) {
        alert("You have successfully logged out.");
        window.location.href = 'index.html'; // Redirect to the homepage after logout
      } else {
        alert("Error logging out. Please try again.");
      }
    } catch (error) {
      console.error('Error during logout:', error);
      alert("An error occurred during logout. Please try again.");
    }
  }
  
  // Sample function to fetch scores (same as before)
  async function fetchScores() {
    try {
      const response = await fetch('http://localhost:5000/api/scores');
      const scores = await response.json();
      displayScores(scores);
    } catch (error) {
      console.error('Error fetching scores:', error);
      alert('Failed to load past scores.');
    }
  }
  
  function displayScores(scores) {
    const scoreList = document.getElementById('score-list');
    if (scores.length === 0) {
      scoreList.innerHTML = '<li>No past quiz scores available.</li>';
    } else {
      scores.forEach(score => {
        const listItem = document.createElement('li');
        listItem.textContent = `Quiz: ${score.quiz_name} | Score: ${score.score} / ${score.total}`;
        scoreList.appendChild(listItem);
      });
    }
  }
  
  // Fetch scores when the page loads
  fetchScores();
  