const express = require('express');
const router = express.Router();
const User = require('/models/User');
const passport = require('passport');

// Signup route
router.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;
    const existingUser = await User.findOne({ email });

    if (existingUser) return res.status(400).send('User already exists.');
    
    const newUser = new User({ username, email, password });
    await newUser.save();
    res.send('User created successfully');
});

// Login route
router.post('/login', passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}));

// Logout route
router.get('/logout', (req, res) => {
    req.logout((err) => {
        if (err) return next(err);
        res.redirect('/');
    });
});

module.exports = router;
